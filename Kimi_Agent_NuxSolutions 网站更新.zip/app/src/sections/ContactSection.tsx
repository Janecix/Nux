import { useRef, useLayoutEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Mail, MapPin, Send, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';

gsap.registerPlugin(ScrollTrigger);

export default function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const leftRef = useRef<HTMLDivElement>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const footerRef = useRef<HTMLElement>(null);

  const [showDialog, setShowDialog] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: '',
  });

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const left = leftRef.current;
    const form = formRef.current;
    const footer = footerRef.current;

    if (!section || !left || !form || !footer) return;

    const ctx = gsap.context(() => {
      // Left content animation
      gsap.fromTo(left,
        { x: '-6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: left,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      // Form animation
      gsap.fromTo(form,
        { x: '6vw', opacity: 0 },
        {
          x: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: form,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      // Footer animation
      gsap.fromTo(footer,
        { opacity: 0 },
        {
          opacity: 1,
          duration: 0.6,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: footer,
            start: 'top 90%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowDialog(true);
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.name]: e.target.value
    }));
  };

  return (
    <section
      ref={sectionRef}
      id="contact"
      className="relative z-[80] bg-nux-light py-[10vh]"
    >
      <div className="px-[6vw] mb-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 max-w-6xl mx-auto">
          {/* Left Content */}
          <div ref={leftRef}>
            <h2 className="font-display text-display-md text-nux-dark uppercase mb-6">
              Let's build reliability—together.
            </h2>
            <p className="text-nux-gray-light text-lg mb-8 max-w-md">
              Tell us what you're running. We'll reply within one business day 
              with a clear plan.
            </p>

            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Mail className="text-nux-orange" size={20} />
                <span className="text-nux-dark">doejohann67@gmail.com</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="text-nux-orange" size={20} />
                <span className="text-nux-gray-light">Remote-first • EU / US timezones</span>
              </div>
            </div>
          </div>

          {/* Form */}
          <div ref={formRef}>
            <form onSubmit={handleSubmit} className="nux-card-light p-8">
              <div className="space-y-6">
                <div>
                  <label className="block font-mono text-xs tracking-[0.08em] text-nux-gray-light uppercase mb-2">
                    Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-transparent border border-nux-dark/20 text-nux-dark focus:border-nux-orange focus:outline-none transition-colors"
                    placeholder="Your name"
                  />
                </div>

                <div>
                  <label className="block font-mono text-xs tracking-[0.08em] text-nux-gray-light uppercase mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 bg-transparent border border-nux-dark/20 text-nux-dark focus:border-nux-orange focus:outline-none transition-colors"
                    placeholder="you@company.com"
                  />
                </div>

                <div>
                  <label className="block font-mono text-xs tracking-[0.08em] text-nux-gray-light uppercase mb-2">
                    Company
                  </label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-transparent border border-nux-dark/20 text-nux-dark focus:border-nux-orange focus:outline-none transition-colors"
                    placeholder="Your company"
                  />
                </div>

                <div>
                  <label className="block font-mono text-xs tracking-[0.08em] text-nux-gray-light uppercase mb-2">
                    Message
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    className="w-full px-4 py-3 bg-transparent border border-nux-dark/20 text-nux-dark focus:border-nux-orange focus:outline-none transition-colors resize-none"
                    placeholder="Tell us about your infrastructure..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-4 bg-nux-orange text-white font-medium flex items-center justify-center gap-2 hover:bg-nux-orange-hover transition-colors"
                >
                  Request a call
                  <Send size={18} />
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer
        ref={footerRef}
        className="border-t border-nux-dark/10 pt-8 px-[6vw]"
      >
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 max-w-6xl mx-auto">
          <div className="font-display font-bold text-nux-dark">
            NuxSolutions
          </div>

          <div className="flex items-center gap-6">
            <button className="text-sm text-nux-gray-light hover:text-nux-dark transition-colors">
              Privacy
            </button>
            <button className="text-sm text-nux-gray-light hover:text-nux-dark transition-colors">
              Terms
            </button>
            <button className="text-sm text-nux-gray-light hover:text-nux-dark transition-colors">
              Security
            </button>
          </div>

          <div className="text-sm text-nux-gray-light">
            © NuxSolutions. All rights reserved.
          </div>
        </div>
      </footer>

      {/* Success Dialog */}
      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent className="bg-nux-light border-nux-dark/10">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl text-nux-dark">
              Message Sent!
            </DialogTitle>
            <DialogDescription className="text-nux-gray-light">
              Thank you for reaching out. We'll get back to you within one business day 
              with a clear plan for your infrastructure.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <button
              onClick={() => setShowDialog(false)}
              className="w-full py-3 bg-nux-orange text-white font-medium flex items-center justify-center gap-2 hover:bg-nux-orange-hover transition-colors"
            >
              Got it
              <ArrowRight size={18} />
            </button>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}
