import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Shield, Calendar } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function SecureSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const card = cardRef.current;
    const bg = bgRef.current;

    if (!section || !headline || !card || !bg) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(bg,
          { scale: 1.08, opacity: 0.7 },
          { scale: 1.00, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(headline,
          { x: '-50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0
        )
        .fromTo(card,
          { x: '50vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0.05
        );

      // EXIT (70% - 100%)
      scrollTl
        .to(headline,
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.70
        )
        .to(card,
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.70
        )
        .to(bg,
          { scale: 1.05, y: '-6vh', ease: 'power2.in' },
          0.70
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="section-pinned z-50"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-[1]"
        style={{
          backgroundImage: 'url(/server_room_walkway.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Vignette Overlay */}
      <div className="vignette-overlay z-[2]" />

      {/* Content Grid */}
      <div className="relative z-[5] h-full grid grid-cols-9 gap-x-[3vw] px-[6vw] items-center">
        {/* Left Content - Headline */}
        <div ref={headlineRef} className="col-span-5">
          <h2 className="font-display text-display-lg text-nux-light uppercase mb-4">
            WE SECURE
          </h2>
          <p className="text-lg text-nux-light/70 max-w-md">
            Patching, hardening, and least-privilege—by default.
          </p>
        </div>

        {/* Right Card */}
        <div
          ref={cardRef}
          className="col-span-4 col-start-6 nux-card p-8"
        >
          <div className="flex items-center gap-3 mb-8">
            <Shield className="text-nux-orange" size={24} />
            <span className="font-mono text-xs tracking-[0.08em] text-nux-light/60 uppercase">
              Security posture
            </span>
          </div>

          <div className="space-y-8">
            {/* Patching */}
            <div className="flex items-center justify-between border-b border-white/10 pb-6">
              <div className="flex items-center gap-3">
                <Calendar className="text-nux-light/40" size={20} />
                <span className="text-nux-light/80">Patching cadence</span>
              </div>
              <span className="font-display text-2xl text-nux-light">
                Weekly
              </span>
            </div>

            {/* Hardening */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Shield className="text-nux-light/40" size={20} />
                <span className="text-nux-light/80">Hardening reviews</span>
              </div>
              <span className="font-display text-2xl text-nux-light">
                Quarterly
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
