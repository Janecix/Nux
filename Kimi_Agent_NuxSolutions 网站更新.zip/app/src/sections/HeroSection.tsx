import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, ChevronDown } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);
  const microcopyRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const panel = panelRef.current;
    const bg = bgRef.current;
    const microcopy = microcopyRef.current;

    if (!section || !headline || !panel || !bg || !microcopy) return;

    const ctx = gsap.context(() => {
      // Load animation (auto-play on mount)
      const loadTl = gsap.timeline();

      loadTl
        .fromTo(bg, 
          { opacity: 0, scale: 1.06 }, 
          { opacity: 1, scale: 1, duration: 1.2, ease: 'power2.out' }
        )
        .fromTo(headline.querySelectorAll('.word'),
          { y: 24, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.06, ease: 'power2.out' },
          '-=0.8'
        )
        .fromTo(panel,
          { x: '40vw', opacity: 0 },
          { x: 0, opacity: 1, duration: 0.8, ease: 'power2.out' },
          '-=0.5'
        )
        .fromTo(microcopy,
          { y: 16, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
          '-=0.3'
        );

      // Scroll-driven animation (pinned)
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onLeaveBack: () => {
            // Reset elements when scrolling back to top
            gsap.set(headline, { x: 0, opacity: 1 });
            gsap.set(panel, { x: 0, opacity: 1 });
            gsap.set(bg, { scale: 1, y: 0 });
          }
        }
      });

      // EXIT phase (70% - 100%)
      scrollTl
        .fromTo(headline,
          { x: 0, opacity: 1 },
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(panel,
          { x: 0, opacity: 1 },
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.7
        )
        .fromTo(bg,
          { scale: 1, y: 0 },
          { scale: 1.06, y: '-6vh', ease: 'power2.in' },
          0.7
        )
        .fromTo(microcopy,
          { opacity: 1 },
          { opacity: 0, ease: 'power2.in' },
          0.75
        );

    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="hero"
      className="section-pinned z-10"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-[1]"
        style={{
          backgroundImage: 'url(/hero_server_night.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Vignette Overlay */}
      <div className="vignette-overlay z-[2]" />

      {/* Content Grid */}
      <div className="relative z-[5] h-full grid grid-cols-9 gap-x-[3vw] px-[6vw] items-center">
        {/* Left Content - Headline Block */}
        <div ref={headlineRef} className="col-span-5">
          <h1 className="font-display text-display-xl text-nux-light uppercase mb-6 word">
            ALWAYS ON
          </h1>
          <p className="text-lg md:text-xl text-nux-light/80 mb-8 max-w-md">
            Linux server management for teams that ship.
          </p>
          <div className="flex flex-wrap gap-4">
            <button
              onClick={() => scrollToSection('contact')}
              className="btn-primary flex items-center gap-2"
            >
              Book a discovery call
              <ArrowRight size={18} />
            </button>
            <button
              onClick={() => scrollToSection('pricing')}
              className="btn-outline"
            >
              See pricing
            </button>
          </div>
        </div>

        {/* Right Panel */}
        <div
          ref={panelRef}
          className="col-span-4 col-start-6 nux-card p-8 h-auto flex flex-col justify-between"
        >
          <div>
            <span className="font-mono text-xs tracking-[0.08em] text-nux-light/60 uppercase">
              Managed Linux infrastructure
            </span>
          </div>
          
          <div className="space-y-6 mt-6">
            {/* Service badges */}
            <div className="flex flex-wrap gap-2">
              <span className="px-3 py-1 bg-nux-orange/20 text-nux-orange text-xs font-mono">Monitoring</span>
              <span className="px-3 py-1 bg-nux-orange/20 text-nux-orange text-xs font-mono">Patching</span>
              <span className="px-3 py-1 bg-nux-orange/20 text-nux-orange text-xs font-mono">Hardening</span>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="w-2 h-2 bg-nux-orange rounded-full animate-pulse" />
              <span className="font-mono text-sm text-nux-light/80">24/7 Monitoring Active</span>
            </div>
            
            <div className="border-t border-white/10 pt-6">
              <p className="text-sm text-nux-light/60 leading-relaxed">
                We keep your Linux servers optimized and operational around the clock, 
                so you can focus on your customers while we manage the backend.
              </p>
            </div>
            
            {/* Quick stats */}
            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10">
              <div>
                <div className="font-display text-2xl text-nux-light">50+</div>
                <div className="text-xs text-nux-light/50">Clients served</div>
              </div>
              <div>
                <div className="font-display text-2xl text-nux-light">99.9%</div>
                <div className="text-xs text-nux-light/50">Uptime guaranteed</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Microcopy */}
      <div
        ref={microcopyRef}
        className="absolute bottom-[6vh] right-[6vw] z-[5]"
      >
        <span className="font-mono text-xs tracking-[0.08em] text-nux-light/50">
          Monitoring • Patching • Hardening
        </span>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-[6vh] left-1/2 -translate-x-1/2 z-[5] animate-bounce">
        <ChevronDown className="text-nux-light/40" size={24} />
      </div>
    </section>
  );
}
