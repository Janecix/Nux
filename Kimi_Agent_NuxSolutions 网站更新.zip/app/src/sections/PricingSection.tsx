import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Check, Server, ArrowRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const plans = [
  {
    name: 'Starter',
    price: '450',
    description: 'Salud básica de servidores',
    servers: '1',
    features: [
      'Hasta 1 servidor Linux',
      'Monitorización automática',
      'Revisión quincenal',
      'Backups verificados',
      'Actualizaciones de seguridad',
      'Informe mensual simple',
      'Respuesta en <48h (horario laboral)',
    ],
    notIncluded: [
      'Incidentes causados por cambios del cliente',
      'Soporte urgente',
      'Proyectos o migraciones',
    ],
    cta: 'Get Starter',
    recommended: false,
  },
  {
    name: 'Core',
    price: '600',
    description: 'Estabilidad operativa',
    servers: '3',
    features: [
      'Hasta 3 servidores Linux estándar',
      'Monitorización 24/7 con alertas filtradas',
      'Revisión semanal',
      'Backups automáticos y pruebas de restauración',
      'Actualizaciones seguras',
      'Soporte correctivo (hasta 3h/mes)',
      'Respuesta en <24h',
      'Informe mensual en lenguaje no técnico',
      'Documentación progresiva de la infraestructura',
    ],
    notIncluded: [
      'Urgencias fuera de horario',
      'Cambios estructurales',
      'Desarrollo o nuevas implementaciones',
    ],
    cta: 'Get Core',
    recommended: true,
  },
  {
    name: 'Pro',
    price: '900',
    description: 'Continuidad crítica',
    servers: '5',
    features: [
      'Hasta 5 servidores Linux',
      'Todo lo del plan Core',
      'Prioridad en alertas críticas',
      'Ventana de atención extendida',
      'Soporte correctivo (hasta 6h/mes)',
      'Revisión de arquitectura trimestral',
      'Asesoría técnica para decisiones de infraestructura',
      'Canal directo (Slack / WhatsApp laboral)',
    ],
    notIncluded: [
      'Emergencias 24/7 humanas',
      'Proyectos grandes sin presupuesto aparte',
    ],
    cta: 'Get Pro',
    recommended: false,
  },
];

export default function PricingSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headingRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const heading = headingRef.current;
    const cards = cardsRef.current;

    if (!section || !heading || !cards) return;

    const ctx = gsap.context(() => {
      // Heading animation
      gsap.fromTo(heading,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: heading,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      // Cards animation
      const cardElements = cards.querySelectorAll('.pricing-card');
      gsap.fromTo(cardElements,
        { y: '10vh', opacity: 0, scale: 0.98 },
        {
          y: 0,
          opacity: 1,
          scale: 1,
          duration: 0.6,
          stagger: 0.12,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: cards,
            start: 'top 70%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  const scrollToContact = () => {
    const element = document.getElementById('contact');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      ref={sectionRef}
      id="pricing"
      className="relative z-[60] bg-nux-dark py-[10vh]"
    >
      {/* Vignette */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-black/30 via-transparent to-black/30" />
      </div>

      <div className="relative z-10 px-[6vw]">
        {/* Heading */}
        <div ref={headingRef} className="text-center mb-16">
          <h2 className="font-display text-display-md text-nux-light uppercase mb-4">
            Choose your plan
          </h2>
          <p className="text-nux-light/60 max-w-xl mx-auto">
            Transparent pricing. No hidden fees. Cancel anytime.
          </p>
        </div>

        {/* Pricing Cards */}
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`pricing-card nux-card p-8 flex flex-col transition-all duration-300 hover:-translate-y-1.5 ${
                plan.recommended ? 'border-nux-orange/50 relative' : ''
              }`}
            >
              {plan.recommended && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-nux-orange text-white text-xs font-mono tracking-[0.08em] px-3 py-1">
                    RECOMMENDED
                  </span>
                </div>
              )}

              {/* Plan Header */}
              <div className="mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Server size={16} className="text-nux-light/40" />
                  <span className="font-mono text-xs tracking-[0.08em] text-nux-light/60 uppercase">
                    {plan.name}
                  </span>
                </div>
                <p className="text-sm text-nux-light/50 mb-4">{plan.description}</p>
                <div className="flex items-baseline gap-1">
                  <span className="font-display text-4xl text-nux-light">{plan.price}</span>
                  <span className="text-nux-light/60">€/mes</span>
                </div>
              </div>

              <div className="border-t border-white/10 my-6" />

              {/* Features */}
              <div className="flex-1">
                <p className="font-mono text-xs tracking-[0.08em] text-nux-light/40 uppercase mb-4">
                  Incluye:
                </p>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <Check size={16} className="text-nux-orange mt-0.5 flex-shrink-0" />
                      <span className="text-sm text-nux-light/80">{feature}</span>
                    </li>
                  ))}
                </ul>

                {plan.notIncluded.length > 0 && (
                  <>
                    <p className="font-mono text-xs tracking-[0.08em] text-nux-light/40 uppercase mb-4">
                      No incluye:
                    </p>
                    <ul className="space-y-2">
                      {plan.notIncluded.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-3">
                          <span className="text-nux-light/30 mt-0.5">—</span>
                          <span className="text-sm text-nux-light/40">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </>
                )}
              </div>

              {/* CTA */}
              <button
                onClick={scrollToContact}
                className={`w-full mt-8 py-3 flex items-center justify-center gap-2 font-medium transition-all duration-200 ${
                  plan.recommended
                    ? 'bg-nux-orange text-white hover:bg-nux-orange/90'
                    : 'border border-nux-orange text-nux-orange hover:bg-nux-orange hover:text-white'
                }`}
              >
                {plan.cta}
                <ArrowRight size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
