import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Activity, Bell } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function MonitorSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLDivElement>(null);
  const leftCardRef = useRef<HTMLDivElement>(null);
  const rightCardRef = useRef<HTMLDivElement>(null);
  const bgRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const headline = headlineRef.current;
    const leftCard = leftCardRef.current;
    const rightCard = rightCardRef.current;
    const bg = bgRef.current;

    if (!section || !headline || !leftCard || !rightCard || !bg) return;

    const ctx = gsap.context(() => {
      const scrollTl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          start: 'top top',
          end: '+=125%',
          pin: true,
          scrub: 0.6,
        }
      });

      // ENTRANCE (0% - 30%)
      scrollTl
        .fromTo(bg,
          { scale: 1.10, y: '10vh', opacity: 0.6 },
          { scale: 1.00, y: 0, opacity: 1, ease: 'none' },
          0
        )
        .fromTo(headline,
          { y: '18vh', opacity: 0 },
          { y: 0, opacity: 1, ease: 'power2.out' },
          0
        )
        .fromTo(leftCard,
          { x: '-40vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0.08
        )
        .fromTo(rightCard,
          { x: '40vw', opacity: 0 },
          { x: 0, opacity: 1, ease: 'power2.out' },
          0.10
        );

      // EXIT (70% - 100%)
      scrollTl
        .to(headline,
          { y: '-10vh', opacity: 0, ease: 'power2.in' },
          0.70
        )
        .to(leftCard,
          { x: '-18vw', opacity: 0, ease: 'power2.in' },
          0.70
        )
        .to(rightCard,
          { x: '18vw', opacity: 0, ease: 'power2.in' },
          0.70
        )
        .to(bg,
          { scale: 1.06, opacity: 0, ease: 'power2.in' },
          0.70
        );

    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="services"
      className="section-pinned z-20"
    >
      {/* Background Image */}
      <div
        ref={bgRef}
        className="absolute inset-0 z-[1]"
        style={{
          backgroundImage: 'url(/corridor_server_room.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      {/* Vignette Overlay */}
      <div className="vignette-overlay z-[2]" />

      {/* Content */}
      <div className="relative z-[5] h-full flex flex-col items-center justify-center px-[6vw]">
        {/* Headline */}
        <div ref={headlineRef} className="text-center mb-12">
          <h2 className="font-display text-display-lg text-nux-light uppercase mb-4">
            WE MONITOR
          </h2>
          <p className="text-lg text-nux-light/70 max-w-2xl mx-auto">
            24/7 alerting, dashboards, and health checks—without the noise.
          </p>
        </div>

        {/* Metric Cards */}
        <div className="flex flex-col md:flex-row gap-6 w-full max-w-4xl">
          {/* Left Card */}
          <div
            ref={leftCardRef}
            className="flex-1 nux-card p-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <Activity className="text-nux-orange" size={24} />
              <span className="font-mono text-xs tracking-[0.08em] text-nux-light/60 uppercase">
                Uptime tracking
              </span>
            </div>
            <div className="font-display text-5xl md:text-6xl text-nux-light">
              99.99<span className="text-nux-orange text-3xl">%</span>
            </div>
          </div>

          {/* Right Card */}
          <div
            ref={rightCardRef}
            className="flex-1 nux-card p-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <Bell className="text-nux-orange" size={24} />
              <span className="font-mono text-xs tracking-[0.08em] text-nux-light/60 uppercase">
                Alert noise reduction
              </span>
            </div>
            <div className="font-display text-5xl md:text-6xl text-nux-light">
              -70<span className="text-nux-orange text-3xl">%</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
