import { useRef, useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Quote, Ticket, Shield, Activity } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const metrics = [
  {
    icon: Ticket,
    value: '12,000+',
    label: 'Tickets resolved',
  },
  {
    icon: Shield,
    value: '8,500+',
    label: 'Patches deployed',
  },
  {
    icon: Activity,
    value: '99.99%',
    label: 'Average uptime',
  },
];

const partners = [
  'TechStart',
  'CloudFirst',
  'DataFlow',
  'SecureStack',
  'LinuxPro',
  'DevOpsHub',
];

export default function TrustSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const metricsRef = useRef<HTMLDivElement>(null);
  const partnersRef = useRef<HTMLDivElement>(null);
  const testimonialRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const section = sectionRef.current;
    const metricsEl = metricsRef.current;
    const partnersEl = partnersRef.current;
    const testimonial = testimonialRef.current;

    if (!section || !metricsEl || !partnersEl || !testimonial) return;

    const ctx = gsap.context(() => {
      // Metrics animation
      const metricItems = metricsEl.querySelectorAll('.metric-item');
      gsap.fromTo(metricItems,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: metricsEl,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      // Partners animation
      const partnerItems = partnersEl.querySelectorAll('.partner-item');
      gsap.fromTo(partnerItems,
        { opacity: 0, scale: 0.98 },
        {
          opacity: 1,
          scale: 1,
          duration: 0.5,
          stagger: 0.08,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: partnersEl,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          }
        }
      );

      // Testimonial animation
      gsap.fromTo(testimonial,
        { y: '6vh', opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power2.out',
          scrollTrigger: {
            trigger: testimonial,
            start: 'top 75%',
            toggleActions: 'play none none reverse',
          }
        }
      );
    }, section);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative z-[70] bg-nux-dark py-[10vh]"
    >
      {/* Vignette */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-transparent to-black/20" />
      </div>

      <div className="relative z-10 px-[6vw]">
        {/* Heading */}
        <div className="text-center mb-16">
          <h2 className="font-display text-display-md text-nux-light uppercase mb-4">
            Trusted by teams that ship
          </h2>
        </div>

        {/* Metrics */}
        <div ref={metricsRef} className="flex flex-col md:flex-row justify-center gap-8 md:gap-16 mb-16">
          {metrics.map((metric, idx) => (
            <div key={idx} className="metric-item text-center">
              <metric.icon className="mx-auto mb-4 text-nux-orange" size={28} />
              <div className="font-display text-4xl md:text-5xl text-nux-light mb-2">
                {metric.value}
              </div>
              <div className="font-mono text-xs tracking-[0.08em] text-nux-light/50 uppercase">
                {metric.label}
              </div>
            </div>
          ))}
        </div>

        {/* Partner Logos */}
        <div ref={partnersRef} className="mb-16">
          <p className="font-mono text-xs tracking-[0.08em] text-nux-light/40 uppercase text-center mb-8">
            Trusted by innovative companies
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            {partners.map((partner, idx) => (
              <div
                key={idx}
                className="partner-item font-display text-lg md:text-xl text-nux-light/40 hover:text-nux-light/60 transition-colors cursor-default"
              >
                {partner}
              </div>
            ))}
          </div>
        </div>

        {/* Testimonial */}
        <div
          ref={testimonialRef}
          className="max-w-3xl mx-auto nux-card p-8 md:p-12"
        >
          <Quote className="text-nux-orange mb-6" size={32} />
          <blockquote className="text-xl md:text-2xl text-nux-light leading-relaxed mb-8">
            "NuxSolutions turned our server chaos into a calm, measurable operation. 
            Best decision we made this quarter."
          </blockquote>
          <div className="flex items-center gap-4">
            <img
              src="/testimonial_avatar.jpg"
              alt="Elena Ruiz"
              className="w-12 h-12 rounded-full object-cover"
            />
            <div>
              <div className="font-medium text-nux-light">Elena Ruiz</div>
              <div className="text-sm text-nux-light/60">CTO, Finscale</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
